# Fine-Tuned Model Package
        
## Conteúdo
- `fine_tuned_model.pkl` - Modelo treinado principal
- `scripts/real_fine_tuning.py` - Classe do fine-tuner
- `scripts/test_fine_tuned_model.py` - Script de teste
- `model_info.json` - Metadados do modelo
- `requirements.txt` - Dependências necessárias

## Instalação
```bash
pip install -r requirements.txt
```

## Uso Básico
```python
from scripts.real_fine_tuning import SimplifiedFineTuner

tuner = SimplifiedFineTuner()
tuner.load_model('fine_tuned_model.pkl')
results = tuner.predict('sua pergunta aqui')
print(results[0]['response'])
```

## Teste
```bash
python scripts/test_fine_tuned_model.py
```

Gerado em: 2025-08-01 15:00:21
